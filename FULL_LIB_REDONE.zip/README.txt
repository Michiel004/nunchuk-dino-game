Compile with $ make

The make command will look for '.c' and '.s' files witch are compiled accordingly.
It outputs a 'kernel.img' file that can run directly on a raspberry pi 3B(+).
