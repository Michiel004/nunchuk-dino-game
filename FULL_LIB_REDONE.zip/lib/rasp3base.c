#include "rasp3base.h"

volatile unsigned int* REG = (unsigned int*)BASE_ADDRESS;