#include "lib/rasp3gpio.h"
#include "lib/rasp3uart.h"
#include "lib/rasp3int.h"

char name[100];
char pass[100];

volatile unsigned int tim;

int mainfunc(){
	RP3_UART_init(115200);
	RP3_GPIO_set_as_output(20);
	
	RP3_UART_send_chars("Wauw, this is working? AMAZING!!!\n");
	RP3_UART_set_repeat_data(1);
	RP3_UART_send_chars("what is your name:\n");
	int amount = RP3_UART_receive_until_char(name, 99, '\r');
	name[amount] = 0; // zero terminated string
	
	RP3_UART_set_repeat_data(0);
	RP3_UART_send_chars("what is your password:\n");
	amount = RP3_UART_receive_until_char(pass, 99, '\r');
	pass[amount] = 0; // zero terminated string
	
	RP3_UART_send_chars("your name is ");
	RP3_UART_send_chars(name);
	RP3_UART_send_chars(" and your pass is ");
	RP3_UART_send_chars(pass);
	RP3_UART_send_chars("\n\n");

	while(1){
	}
	return 0;
}
